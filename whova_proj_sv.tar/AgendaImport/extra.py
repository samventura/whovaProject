##################
# Helper stuff

# book = xlrd.open_workbook("agenda.xls")

# print("The number of worksheets is {0}".format(book.nsheets))

# print("Worksheet name(s): {0}".format(book.sheet_names()))

# sh = book.sheet_by_index(0)

# print("{0} {1} {2}".format(sh.name, sh.nrows, sh.ncols))

# Print sheet information
# print("Sheet name:", sh.name)
# print("Number of rows:", sh.nrows)
# print("Number of columns:", sh.ncols)

# Get a specific cell value (e.g., cell D30, which is row index 29, column index 3)
# cell_value = sh.cell_value(rowx=29, colx=3)
# print("Cell D30 is:", cell_value)

# Iterate over all rows and print values
# for row_index in range(sh.nrows):
#     row_values = sh.row_values(row_index)
#     print(row_values)

# End Helper stuff

##################